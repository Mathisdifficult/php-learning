<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/3/28
 * Time: 22:31
 */
session_start();
echo $_SESSION['userID']."你好"."<br>";
?>